import { useState } from "react";

export const Rejestracja = () => {
    const[name, setName] = useState("");
    const[date, setDate] = useState("");
    const[hour, setHour] = useState("");


    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("Imię i nazwisko: " + name + "; Data wizyty: " + date + "; Godzina wizyty: " + hour);
    }
    return (
        <>
            <form>
                <div className="form-group">
                    <label htmlFor="name">Imie i nazwisko</label>
                    <input className="form-control" type="text" id="name" onChange={e => setName(e.target.value)}/>
                </div>
                
                <br></br>

                <div className="form-group">
                    <label htmlFor="appointmentDate">Data wizyty</label>
                    <input className="form-control" type="date" id="appointmentDate" onChange={e => setDate(e.target.value)}/>
                </div>
                
                <br></br>

                <div className="form-group">
                    <label htmlFor="hour">Godzina</label>
                    <select className="form-control" id="hour" onChange={e => setHour(e.target.value)}>
                        <option></option>
                        <option>15.00</option>
                        <option>16.00</option>
                        <option>17.00</option>
                        <option>18.00</option>
                    </select>
                </div>
                
                <br></br>

                <input className="btn btn-primary" type="submit" value="Zarejestruj" onClick={handleSubmit}/>
            </form>
        </>
    )
}

