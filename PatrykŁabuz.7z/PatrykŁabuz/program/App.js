import { useState } from "react";
import {Rejestracja} from './components/component.jsx';
import './style.css';

function App() {
  return (
    <div>
      <Rejestracja/>
    </div>
  );
}

export default App;
