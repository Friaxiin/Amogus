﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PracaNaLekcji_Bookmarks
{
    /// <summary>
    /// Logika interakcji dla klasy EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        Book Book = null;
        public EditWindow(Book book)
        {
            InitializeComponent();
            Book = book;
            titleEntry.Text = book.Title;
            descEntry.Text = book.Description;
            authorEntry.Text = book.Author;
            urlEntry.Text = book.Url;
        }

        private void EditBook(object sender, RoutedEventArgs e)
        {
            Book newBook = new Book(titleEntry.Text, authorEntry.Text, descEntry.Text, urlEntry.Text);
            Database.EditBook(Book, newBook);
            this.Close();
        }
    }
}
