﻿using Microsoft.Data.Sqlite;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracaNaLekcji_Bookmarks
{
    public static class Database
    {
        private static readonly string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "books.db");

        public static void CreateTables()
        {
            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var CreateCommand = new SqliteCommand();
                CreateCommand.Connection = db;
                CreateCommand.CommandText = "CREATE TABLE IF NOT EXISTS Books (bookId INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, description TEXT, coverUrl TEXT)";
                CreateCommand.ExecuteReader().Close();
                CreateCommand.CommandText = "CREATE TABLE IF NOT EXISTS Bookmarks (bookmarkId INTEGER PRIMARY KEY AUTOINCREMENT, page_number INTEGER, description TEXT, book_id INTEGER)";
                CreateCommand.ExecuteReader();
            }
        }
        public static List<Book> ReadBooks()
        {
            var entries = new List<Book>();
            if(File.Exists(dbPath))
            {
                using (var db = new SqliteConnection($"Filename={dbPath}"))
                {
                    db.Open();
                    var selectCommand = new SqliteCommand();
                    selectCommand.Connection = db;
                    selectCommand.CommandText = "SELECT * FROM Books";
                    SqliteDataReader reader = selectCommand.ExecuteReader();
                    while (reader.Read())
                    {
                        Book book = new Book(reader.GetInt32(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4));
                        entries.Add(book);
                    }
                }
            }
            return entries;
        }
        public static void AddBook(Book book)
        {
            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var insertCommand = new SqliteCommand();
                insertCommand.Connection = db;
                insertCommand.CommandText = "INSERT INTO Books (title, author, description, coverUrl) VALUES (@title, @author, @desc, @url)";
                insertCommand.Parameters.AddWithValue("@title", book.Title);
                insertCommand.Parameters.AddWithValue("@author", book.Author);
                insertCommand.Parameters.AddWithValue("@desc", book.Description);
                insertCommand.Parameters.AddWithValue("@url", book.Url);
                insertCommand.ExecuteReader();
            }
        }
        public static void DeleteBook(Book book)
        {
            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var deleteCommand = new SqliteCommand();
                deleteCommand.Connection = db;
                deleteCommand.CommandText = "DELETE FROM Books WHERE bookId=@id";
                deleteCommand.Parameters.AddWithValue("@id", book.Id);
                deleteCommand.ExecuteReader();
            }
        }
        public static List<Bookmark> ReadBookmarks(Book book)
        {
            var entries = new List<Bookmark>();
            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var selectCommand = new SqliteCommand();
                selectCommand.Connection = db;
                selectCommand.CommandText = "SELECT * FROM Bookmarks WHERE book_Id = @bookId";
                selectCommand.Parameters.AddWithValue("@bookId", book.Id);
                SqliteDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Bookmark bookmark = new Bookmark(reader.GetInt32(0), reader.GetInt32(1), reader.GetString(2), reader.GetInt32(3));
                    entries.Add(bookmark);
                }
            }
            return entries;
        }
        public static void AddBookmark(Bookmark bookmark)
        {
            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var insertCommand = new SqliteCommand();
                insertCommand.Connection = db;
                insertCommand.CommandText = "INSERT INTO Bookmarks (page_number, description, book_Id) VALUES (@pgNum, @desc, @bookId)";
                insertCommand.Parameters.AddWithValue("@pgNum", bookmark.PageNumber);
                insertCommand.Parameters.AddWithValue("@desc", bookmark.Description);
                insertCommand.Parameters.AddWithValue("@bookId", bookmark.BookId);
                insertCommand.ExecuteReader();
            }
        }
    }

}
